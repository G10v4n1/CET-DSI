package com.example.demo.controllers;

// import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;;

@RestController
public class Hello {

    @GetMapping("/hello")
    public String helloWorldGet(){
        return "Hello world!\t This is a sample message.";
    }

    @PostMapping("/hello")
    public String helloWorldPost(){
        return "Hello POST";
    }

    @PutMapping("/hello")
    public String helloWorldPut(){
        return "Hello PUT";
    }

    @DeleteMapping("/hello")
    public String helloWorldDelete(){
        return "Hello DEL";
    }

}
